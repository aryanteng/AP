public class Instructor {
    String name;
    Instructor(String myname){
        name = myname;
    }
}
