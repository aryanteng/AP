public interface Lecture {
    public void display();
}
